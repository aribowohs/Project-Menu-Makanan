package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> FotoMakanan = new ArrayList<>();
    private ArrayList<String> NamaMakanan = new ArrayList<>();
    private ArrayList<String> InfoMakanan = new ArrayList<>();
    private ArrayList<String> HargaMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(FotoMakanan, NamaMakanan, InfoMakanan, HargaMakanan,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    private void getDataFromInternet(){
        NamaMakanan.add("Lumpia");
        FotoMakanan.add("https://asset-a.grid.id/crop/0x0:0x0/700x465/photo/sasefoto/original/35931_lumpia-semarang.jpg");
        InfoMakanan.add("Lumpia adalah makanan semacam rollade yang berisi rebung, telur, dan daging ayam atau udang.\n" +
                "Cita rasa lumpia semarang adalah perpaduan rasa antara Tionghoa dan Indonesia karena pertama kali dibuat oleh seorang keturunan Tionghoa yang menikah dengan orang Indonesia dan menetap di Semarang, Jawa Tengah.");
        HargaMakanan.add("Harga : Rp 40.000");

        NamaMakanan.add("Tahu Bakso");
        FotoMakanan.add("https://asset.kompas.com/crops/7IdRwZpcpYsImnHe2nB5pZrPTgM=/0x0:1000x667/750x500/data/photo/2020/08/05/5f2a43ad5bd07.jpg");
        InfoMakanan.add("Tahu Bakso adalah makanan khas Indonesia yang berasal dari Kota Ungaran, Kabupaten Semarang, Jawa Tengah. \n" +
                "Makanan ini dibuat dari tahu yang tengahnya diberi isi bakso. \n" +
                "Makanan ini memiliki ciri khas dihidangkan dengan sambal kecap dengan irisan cabe rawit dan saus bumbu kacang.");
        HargaMakanan.add("Harga : Rp 20.000");

        NamaMakanan.add("Getuk");
        FotoMakanan.add("https://cdn2.tstatic.net/tribunnewswiki/foto/bank/images/getukk.jpg");
        InfoMakanan.add("Adalah makanan ringan yang terbuat dengan bahan utama ketela pohon atau singkong. \n" +
                "Getuk merupakan makanan yang mudah ditemukan di Jawa Tengah dan Jawa Timur. Pembuatan getuk diawali dengan mengupas singkong dan merebusnya. Setelah matang singkong ditumbuk atau dihaluskan dengan cara digiling lalu diberi pemanis gula dan pewarna makanan.");
        HargaMakanan.add("Harga : Rp 15.000");

        NamaMakanan.add("Martabak");
        FotoMakanan.add("https://i.pinimg.com/originals/bd/51/7c/bd517c673b7ac17d4583eaa3f9c5f207.jpg");
        InfoMakanan.add("Di Indonesia ada dua jenis martabak, yaitu martabak asin/telur yang terbuat dari campuran telur dan daging serta martabak manis, padahal yang benar(kue terang bulan) yang biasanya di isi coklat dan keju. Berbeda dengan martabak telur, martabak manis adalah sejenis kue atau roti isi selai yang biasa dimakan di saat santai sebagai makanan ringan.");
        HargaMakanan.add("Harga : Rp 15.000 - Rp 80.000");

        NamaMakanan.add("Rawon");
        FotoMakanan.add("https://cdn-2.tstatic.net/tribunnews/foto/bank/images/rawon.jpg");
        InfoMakanan.add("Rawon adalah masakan Indonesia berupa sup daging berkuah hitam dengan campuran bumbu khas yang menggunakan kluwek. \n" +
                "Rawon meskipun dikenal sebagai masakan khas Jawa Timur (daerah Arekan), dikenal pula oleh masyarakat Jawa Tengah sebelah timur (daerah Surakarta).");
        HargaMakanan.add("Harga : Rp 20.000");

        prosesRecyclerViewAdapter();
    }
}